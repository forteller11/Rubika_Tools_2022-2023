using UnityEngine;

public class Class06Exercise0_1 : MonoBehaviour
{
    public Vector3 Vector = new Vector3(1, 2, 4);

    private void Start()
    {
        Vector.y = 10;
    }
}
